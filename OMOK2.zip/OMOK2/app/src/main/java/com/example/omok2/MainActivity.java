package com.example.omok2;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import com.google.android.material.floatingactionbutton.FloatingActionButton;import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;import android.util.DisplayMetrics;import android.view.Display;import android.view.View;import android.view.Menu;import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends Activity {
    final static int maxN=15;

    private ImageView[][] ivCell = new ImageView[maxN][maxN];
    private Context context;


    private Drawable[] drawCell = new Drawable[4];

    private Button btnPlay;
    private TextView tvTurn;
    private int[][] valueCell = new int[maxN][maxN];
    private int winner_play ;
    private boolean firstMove;
    private int xmove, yMove;//플레이어나 봇이 선택가능한 위치
    private int turnPlay;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = this;
        setListen();
        loadResources();
        designBoardGame();
    }

    private void loadResources() {
        drawCell[3] = context.getResources().getDrawable(R.drawable.cell_bg);

        drawCell[0] = null;

        drawCell[1] = context.getResources().getDrawable(R.drawable.flame);

        drawCell[2]=context.getResources().getDrawable(R.drawable.flame2);
    }

    private void setListen() {
        btnPlay =(Button)findViewById(R.id.btnplay);
        tvTurn = (TextView)findViewById(R.id.tvTurn);


        btnPlay.setText("Play Game");
        tvTurn.setText("Press button to play game");

        btnPlay.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                init_game();
                play_game();
            }
        }));
    }

    private void play_game() {
        Random r = new Random();
        turnPlay = r.nextInt(2)+1;

        if(turnPlay == 1){

            Toast.makeText(context,"player play first !",Toast.LENGTH_SHORT).show();
            playerTurn();
        }else{
            Toast.makeText(context,"bot play first",Toast.LENGTH_SHORT).show();
            botTurn();
        }

    }

    private void botTurn() {

        tvTurn.setText("bot");

        if(firstMove){
            xmove=7; yMove=7;
            make_a_move();
        }
        else{
            findBotMove();
            make_a_move();
        }
    }

    private final int[] iRow={-1,-1,-1,0,1,1,1,0};
    private final int[] iCol={-1,0,1,1,1,0,-1,-1};
    private void findBotMove() {
        List<Integer> listX = new ArrayList<Integer>();
        List<Integer> listY = new ArrayList<Integer>();

        final int range=2;
        for(int i=0;i<maxN;i++){
            for(int j=0;j<maxN;j++){

                if(valueCell[i][j] !=0){
                    for(int t = 0;t<range;t++){
                        for(int k =0 ;k<8;k++){
                            int x = i + iRow[k]*t;
                            int y = j + iCol[k]*t;
                            if(inBoard(x,y) && valueCell[x][y] ==0){
                                listX.add(x);
                                listY.add(y);
                            }
                        }
                    }
                }

            }

        }
        int lx = listX.get(0);
        int ly = listY.get(0);

        int res = Integer.MAX_VALUE -10;
        for(int i=0;i<listX.size();i++){
            int x= listX.get(i);
            int y= listY.get(i);
            valueCell[x][y]=2;
            int rr = getValue_Position();
            if(rr<res){
                res = rr;
                lx= x;
                ly = y;
            }
            valueCell[x][y]=0;
        }
        xmove= lx;
        yMove=ly;
    }

    private int getValue_Position() {

        int rr=0;
        int pl = turnPlay;

        for(int i=0;i<maxN;i++){
            rr +=CheckValue(maxN-1,i,-1,0,pl);
        }
        for(int i=0;i<maxN;i++){
            rr +=CheckValue(i, maxN-1,0,-1,pl);
        }
        for(int i=maxN-1;i>=0;i--){
            rr+=CheckValue(i,maxN-1,-1,-1,pl);
        }
        for(int i=maxN-2;i>=0;i--){
            rr+=CheckValue(maxN-1,i,-1,-1,pl);
        }
        //
        for(int i=maxN-1;i>=0;i--){
            rr+=CheckValue(i,0,-1,1,pl);
        }
        for(int i=maxN-1;i>=1;i--){
            rr+=CheckValue(maxN-1,i,-1,1,pl);
        }

        return rr;

    }

    private int CheckValue(int xd, int yd, int vx, int vy, int pl) {

        int i,j;
        int rr=0;
        i=xd; j =yd;
        String at= String.valueOf(valueCell[i][j]);

        while(true){
            i+=vx; j+=vy;
            if(inBoard(i,j)){
                at = at+String.valueOf(valueCell[i][j]);
                if(at.length() == 6){
                    rr+=Eval(at,pl);
                    at=at.substring(1,6);
                }

            }else break;
        }
        return rr;
    }

    private void make_a_move() {
        ivCell[xmove][yMove].setImageDrawable(drawCell[turnPlay]);
        valueCell[xmove][yMove]=turnPlay;

        if(noEmptycell()){
            Toast.makeText(context,"Draw!!",Toast.LENGTH_SHORT).show();
            return;
        }else if (CheckWinner()) {
            if (winner_play == 1) {
                Toast.makeText(context, "winner is  player", Toast.LENGTH_SHORT).show();
                tvTurn.setText("winnner is player! good gob!");

            }else{
                Toast.makeText(context,"winner is bot, you lose..",Toast.LENGTH_SHORT).show();
                tvTurn.setText("oh nah Bruh! U lose.");

            }
        }

        if(turnPlay ==1){
            turnPlay= (1+2) - turnPlay;
            botTurn();
        }
        else {
            turnPlay= 3 - turnPlay;
            playerTurn();
        }
    }

    private boolean CheckWinner() {
        if(winner_play != 0)
            return true;

        VectorEnd(xmove,0,0,1,xmove,yMove);
        VectorEnd(0,yMove,1,0,xmove,yMove);

        if(xmove + yMove >= maxN-1){
            VectorEnd(maxN-1,xmove+yMove-maxN+1,-1,1,xmove,yMove);

        }else {
            VectorEnd(xmove + yMove, 0, -1, 1, xmove, yMove);
        }
        if(xmove<yMove){
            VectorEnd(xmove-yMove+maxN-1,maxN-1,-1,-1,xmove,yMove);

        }
        else{
            VectorEnd(maxN-1,maxN-1-(xmove-yMove),-1,-1,xmove,yMove);
        }
        if(winner_play != 0) return true; else
        return false;
    }

    private void VectorEnd(int xx, int yy, int vx, int vy, int rx, int ry) {

        if(winner_play != 0) return;
        final int range = 4;

        int i,j;
        int xbelow = rx-range*vx;
        int ybelow = ry - range*vy;
        int xabove = rx+range*vx;
        int yabove= ry+range*vy;

        String at = "";
        i = xx; j = yy;

        while(!inside(i,xbelow,xabove) || !inside(j,ybelow,yabove)){
            i+=vx; j+=vy;
        }
        while (true){
            at=at+String.valueOf(valueCell[i][j]);
            if(at.length() == 5){
                EvalEnd(at);
                at=at.substring(1,5);
            }
            i+=vx;j+=vy;
            if(!inBoard(i,j) || !inside(i,xbelow,xabove) || !inside(j,ybelow,yabove) || winner_play !=0){
                break;
            }
        }

    }

    private boolean inBoard(int i, int j) {
        if(i<0 || i>maxN-1 || j<0 || j>maxN-1)
            return false;
        return true;
    }

    private void EvalEnd(String at) {
        switch (at){
            case "11111": winner_play = 1;break;
            case "22222": winner_play = 2;break;
            default:break;
        }

    }

    private boolean inside(int i, int xbelow, int xabove) {
        return (i-xbelow)*(i-xabove)<=0;
    }

    private boolean noEmptycell() {
        for(int i=0;i<maxN;i++){
            for(int j=0;j<maxN;j++){
                if(valueCell[i][j] == 0)
                    return false;
            }
        }

        return true;
    }

    private void playerTurn() {
        tvTurn.setText("player");
        firstMove = false;
        isClicked = false;
    }

    private void init_game() {

        firstMove = true;
        winner_play =0;
        for(int i=0;i<maxN;i++){
            for(int j=0;j<maxN;j++){
                ivCell[i][j].setImageDrawable(drawCell[0]);
                valueCell[i][j] = 0;
            }
        }
    }

    private boolean isClicked;
    @SuppressLint("NewApi")
    private void designBoardGame()
    {
        int sizeofCell = Math.round(ScreenWidth() / maxN);
        LinearLayout.LayoutParams lpRow = new LinearLayout.LayoutParams(sizeofCell * maxN, sizeofCell);
        LinearLayout.LayoutParams lpCell = new LinearLayout.LayoutParams(sizeofCell, sizeofCell);

        LinearLayout linBoardGame = (LinearLayout)findViewById(R.id.linBoardGame);

        for(int i=0;i<maxN;i++){
            LinearLayout linRow = new LinearLayout(context);
            for(int j=0;j<maxN;j++){
                ivCell[i][j] = new ImageView(context);

                ivCell[i][j].setBackground(drawCell[3]);
                //여기 주의
                final int x =i;
                final int y =j;
                ivCell[i][j].setOnClickListener((new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(valueCell[x][y] ==0){
                            if(turnPlay ==1 || !isClicked){
                                isClicked = true;
                                xmove = x; yMove = y;
                                make_a_move();
                            }
                        }

                    }
                }));

                linRow.addView(ivCell[i][j],lpCell);
            }

            linBoardGame.addView(linRow,lpRow);
        }
    }

    private float ScreenWidth(){
        Resources resources = context.getResources();

        DisplayMetrics dm = resources.getDisplayMetrics();
        return dm.widthPixels;
    }

    //funtionevalute
    private int Eval(String at, int pl){
        int b1 = 1,b2=1;
        if(pl == 1){
            b1=2;
            b2=1;
        }
        else{
            b1=1;
            b2=2;
        }
        switch (at){
            case "111110":return b1*10000000;
            case "011111":return b1*10000000;
            case "211111":return b1*10000000;
            case "111112":return b1*10000000;
            case "011110":return b1*1002;
            case "101110":return b1*1002;
            case "011101":return b1*1002;
            case "011112":return b1*1000;
            case "0111100":return b1*102;
            case "001110":return b1*102;
            case "210111":return  b1*100;
            case "211110":return  b1*100;
            case "211011":return  b1*100;
            case "211101":return  b1*100;
            case "010100":return  b1*10;
            case "011000":return  b1*10;
            case "001100":return  b1*10;
            case "000110":return  b1*10;
            case "211000":return  b1*1;
            case "201100":return  b1*1;
            case "200110":return  b1*1;
            case "200011":return  b1*1;
            case "222220":return  b1*-100000000;
            case "022222":return  b1*-100000000;
            case "122222":return  b1*-100000000;
            case "222221":return  b1*-100000000;
            case "022220":return  b1*-10000000;
            case "202220":return  b1*-1002;
            case "022202":return  b1*-1002;
            case "022200":return  b1*-102;
            case "002220":return  b1*-102;
            case "120222":return  b1*-100;
            case "122220":return  b1*-100;
            case "122022":return  b1*-100;
            case "122202":return  b1*-100;
            case "020200":return  b1*-10;
            case "022000":return  b1*-10;
            case "002200":return  b1*-10;
            case "000220":return  b1*-10;
            case "122000":return  b1*-1;
            case "102200":return  b1*-1;
            case "100220":return  b1*-1;
            case "100022":return  b1*-1;
            default:
                break;
        }
    return 0;
    }

}


